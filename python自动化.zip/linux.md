# linux 基本命令 #
    chown（change owner）：修改所属用户与组
	chmod（change mode）：修改用户的权限
	ll， ls -l ：命令显示一个文件的属性以及文件所属的用户和组	
## 文件基本属性 ##
> bin文件第一个属性用d表示，当为d则是目录，当为-则是文件，若是l则表示为链接文档（link file），若是b则表示为装置文件里面的可供储存的接口设备（可随机存取装置）；若是c则表示为装置文件里面的串行端口设备，例如键盘、鼠标（一次行读取装置）。
> 
> 接下来的字符中，以三个为一组，且均为 rwx 的三个参数的组合。其中， r 代表可读(read)、 w 代表可写(write)、 x 代表可执行(execute)。 要注意的是，这三个权限的位置不会改变，如果没有权限，就会出现减号 - 而已。
> 
![](https://www.runoob.com/wp-content/uploads/2014/06/363003_1227493859FdXT.png)

## 更改文件属性 ##
### 1、chgrp：更改文件数组 ### 


    chgrp [R] 属主名 文件名

> 参数选项 
> 
> -R：递归更改文件属组，就是在更改某个目录文件的属组时，如果加上-R的参数，那么该目录下的所有文件的属组都会更改。
### 2、chown：更改文件属主，也可以同时更改文件属组 ###
> chown [–R] 属主名 文件名
> 
> chown [-R] 属主名：属组名 文件名

	[root@www ~]# chown root:root install.log
	[root@www ~]# ls -l
	-rw-r--r--  1 root root 68495 Jun 25 08:53 install.log

#### 3、chmod：更改文件9个属性 ####
> Linux文件属性有两种设置方法，一种是数字，一种是符号。
> 
> Linux 文件的基本权限就有九个，分别是 owner/group/others(拥有者/组/其他) 三种身份各有自己的 read/write/execute 权限。

数字类型改变文件权限

> 各权限的分数对照表如下：	r:4、w:2	、x:1
> 
    chmod [-R] xyz 文件或目录
	[root@www ~]# ls -al .bashrc
	-rw-r--r--  1 root root 395 Jul  4 11:45 .bashrc
	[root@www ~]# chmod 777 .bashrc
	[root@www ~]# ls -al .bashrc
	-rwxrwxrwx  1 root root 395 Jul  4 11:45 .bashrc


> 选项与参数：
> 
> xyz : 就是刚刚提到的数字类型的权限属性，为 rwx 属性数值的相加。
> 
> -R : 进行递归(recursive)的持续变更，以及连同次目录下的所有文件都会变更

符号类型改变文件权限
>  u, g, o 来代表三种身份的权限， a 则代表 all，即全部的身份

	chmod u=rwx,g=rx,o=r 文件名
	[root@www ~]# touch test1    // 创建 test1 文件
	[root@www ~]# ls -al test1    // 查看 test1 默认权限
	-rw-r--r-- 1 root root 0 Nov 15 10:32 test1
	[root@www ~]# chmod u=rwx,g=rx,o=r  test1    // 修改 test1 权限
	[root@www ~]# ls -al test1
	-rwxr-xr-- 1 root root 0 Nov 15 10:32 test1

	chmod u=rx,g-x,o+w 文件名
	[root@www ~]# ls -al test1    // 查看 test1 默认权限
	-rwxr-xr-- 1 root root 0 Nov 15 10:32 test1
	[root@www ~]# chmod u=rx,g-x,o+w  test1    // 修改 test1 权限
	[root@www ~]# ls -al test1
	-r-xr--rw- 1 root root 0 Nov 15 10:32 test1
	

	chmod a-r 文件名		// 拿掉全部人的可执行权限r
	[root@www ~]# ls -al test1    // 查看 test1 默认权限
	-r-xr--rw- 1 root root 0 Nov 15 10:32 test1
	[root@www ~]# chmod a-r  test1    // 修改 test1 权限
	[root@www ~]# ls -al test1
	---x----w- 1 root root 0 Nov 15 10:32 test1

## 文件与目录管理 ##
### 常用命令 ###
    ls（英文全拼：list files）: 列出目录及文件名   -a、-d、-l
	cd（英文全拼：change directory）：切换目录
	pwd（英文全拼：print work directory）：显示目前的目录
	mkdir（英文全拼：make directory）：创建一个新的目录
	rmdir（英文全拼：remove directory）：删除一个空的目录
	cp（英文全拼：copy file）: 复制文件或目录
	rm（英文全拼：remove）: 删除文件或目录
	mv（英文全拼：move file）: 移动文件与目录，或修改文件与目录的名称
	你可以使用 man [命令] 来查看各个命令的使用文档，如 ：man cp
	touch（英文全拼：change file timestamps）：修改文件或者目录的时间属性，包括存取时间和更改时间。若文件不存在，系统会建立一个新的文件。
### Linux 文件内容查看 ###
	cat  由第一行开始显示文件内容	-n ：列印出行号，连同空白行也会有行号
	tac  从最后一行开始显示，可以看出 tac 是 cat 的倒着写！
	nl   显示的时候，顺道输出行号！
	more 一页一页的显示文件内容
	less 与 more 类似，但是比 more 更好的是，他可以往前翻页！
	head 只看头几行
	tail 只看尾巴几行
	vim 编辑文件，当无该文件则创建	

## 用户和用户组管理 ##
### Linux系统用户账号的管理 ###
1、添加新的用户账号使用useradd命令

    useradd 选项 用户名

> 选项:
> 
> -d 目录 指定用户主目录，如果此目录不存在，则同时使用-m选项，可以创建主目录。
> 
> -g 用户组 指定用户所属的用户组。
> 
> -G 用户组，用户组 指定用户所属的附加组。
> 
> -s Shell文件 指定用户的登录Shell。
> 
> 用户名:指定新账号的登录名。

    # useradd –d  /home/sam -m sam
> 此命令创建了一个用户sam，其中-d和-m选项用来为登录名sam产生一个主目录 /home/sam（/home为默认的用户主目录所在的父目录）。

    # useradd -s /bin/sh -g group –G adm,root gem
> 此命令新建了一个用户gem，该用户的登录Shell是 /bin/sh，它属于group用户组，同时又属于adm和root用户组，其中group用户组是其主组

2、删除一个已有的用户账号使用userdel命令

    userdel 选项 用户名
> 常用的选项是 -r，它的作用是把用户的主目录一起删除。

    # userdel -r sam
	# userdel -r sam
> 此命令删除用户sam在系统文件中（主要是/etc/passwd, /etc/shadow, /etc/group等）的记录，同时删除用户的主目录。

3、修改已有用户的信息使用usermod命令

    usermod 选项 用户名
	# usermod -s /bin/ksh -d /home/z –g developer sam

> 常用的选项包括-c, -d, -m, -g, -G, -s, -u以及-o等，这些选项的意义与useradd命令中的选项一样，可以为用户指定新的资源值。

4、指定和修改用户口令的Shell命令是passwd。超级用户可以为自己和其他用户指定口令，普通用户只能用它修改自己的口令。

    passwd 选项 用户名
> 可使用的选项：

> -l 锁定口令，即禁用账号。

> -u 口令解锁。
> 
> -d 使账号无口令。
> 
> -f 强迫用户下次登录时修改口令。
> 
如果默认用户名，则修改当前用户的口令。

> 假设当前用户是sam，则下面的命令修改该用户自己的口令：
> 
    $ passwd 
	Old password:****** 
	New password:******* 
	Re-enter new password:*******

> 如果是超级用户，可以用下列形式指定任何用户的口令：

    # passwd sam 
	New password:******* 
	Re-enter new password:*******

## Linux系统用户组的管理 ##
1、增加一个新的用户组使用groupadd命令。其格式如下：

    groupadd 选项 用户组
> 可以使用的选项有：
> 
> -g GID 指定新用户组的组标识号（GID）。
> 
> -o 一般与-g选项同时使用，表示新用户组的GID可以与系统已有用户组的GID相同。

2、如果要删除一个已有的用户组，使用groupdel命令，其格式如下：

    groupdel 用户组

3、修改用户组的属性使用groupmod命令。其语法如下：

    groupmod 选项 用户组

> 常用的选项有：
> 
> -g GID 为用户组指定新的组标识号。
> 
> -o 与-g选项同时使用，用户组的新GID可以与系统已有用户组的GID相同。
> 
> -n新用户组 将用户组的名字改为新名字

4、用户可以在登录后，使用命令newgrp切换到其他用户组，这个命令的参数就是目的用户组。

    $ newgrp root
> 这条命令将当前用户切换到root用户组，前提条件是root用户组确实是该用户的主组或附加组。类似于用户账号的管理，用户组的管理也可以通过集成的系统管理工具来完成。

## 与用户账号有关的系统文件 ##
1、Linux系统中的每个用户都在/etc/passwd文件中有一个对应的记录行，它记录了这个用户的一些基本属性。这个文件对所有用户都是可读的。

    ＃ cat /etc/passwd
	root:x:0:0:Superuser:/:
	daemon:x:1:1:System daemons:/etc:
	bin:x:2:2:Owner of system commands:/bin:
	sys:x:3:3:Owner of system files:/usr/sys:
	adm:x:4:4:System accounting:/usr/adm:
	uucp:x:5:5:UUCP administrator:/usr/lib/uucp:
	auth:x:7:21:Authentication administrator:/tcb/files/auth:
	cron:x:9:16:Cron daemon:/usr/spool/cron:
	listen:x:37:4:Network daemon:/usr/net/nls:
	lp:x:71:18:Printer administrator:/usr/spool/lp:
	sam:x:200:50:Sam san:/home/sam:/bin/sh
	用户名:口令:用户标识号:组标识号:注释性描述:主目录:登录Shell

	伪 用 户 含 义 
	bin 拥有可执行的用户命令文件 
	sys 拥有系统文件 	
	adm 拥有帐户文件 
	uucp UUCP使用 
	lp lp或lpd子系统使用 
	nobody NFS使用

# linux磁盘管理 #
> Linux 磁盘管理常用三个命令为 df、du 和 fdisk。

> df（英文全称：disk free）：列出文件系统的整体磁盘使用量

> du（英文全称：disk used）：检查磁盘空间使用量

> fdisk：用于磁盘分区

1、df命令参数功能：检查文件系统的磁盘空间占用情况。可以利用该命令来获取硬盘被占用了多少空间，目前还剩下多少空间等信息。

    df [-ahikHTm] [目录或文件名]
> 选项与参数：
> -a ：列出所有的文件系统，包括系统特有的 /proc 等文件系统；

> -k ：以 KBytes 的容量显示各文件系统；

> -m ：以 MBytes 的容量显示各文件系统；

> -h ：以人们较易阅读的 GBytes, MBytes, KBytes 等格式自行显示；

> -H ：以 M=1000K 取代 M=1024K 的进位方式；

> -T ：显示文件系统类型, 连同该 partition 的 filesystem 名称 (例如 ext3) 也列出；

> -i ：不用硬盘容量，而以 inode 的数量来显示

2、Linux du 命令也是查看使用空间的，但是与 df 命令不同的是 Linux du 命令是对文件和目录磁盘使用的空间的查看，还是和df命令有一些区别的，这里介绍 Linux du 命令。
    du [-ahskm] 文件或目录名称

> 选项与参数：

> -a ：列出所有的文件与目录容量，因为默认仅统计目录底下的文件量而已。

> -h ：以人们较易读的容量格式 (G/M) 显示；

> -s ：列出总量而已，而不列出每个各别的目录占用容量；

> -S ：不包括子目录下的总计，与 -s 有点差别。

> -k ：以 KBytes 列出容量显示；

> -m ：以 MBytes 列出容量显示；

3、fdisk 是 Linux 的磁盘分区表操作工具。

    fdisk [-l] 装置名称
> 选项与参数：

> -l ：输出后面接的装置所有的分区内容。若仅有 fdisk -l 时， 则系统将会把整个系统内能够搜寻到的装置的分区均列出来。

4、fsck（file system check）用来检查和维护不一致的文件系统。若系统掉电或磁盘发生问题，可利用fsck命令对文件系统进行检查。

    fsck [-t 文件系统] [-ACay] 装置名称


> 选项与参数：

> -t : 给定档案系统的型式，若在 /etc/fstab 中已有定义或 kernel 本身已支援的则不需加上此参数

> -s : 依序一个一个地执行 fsck 的指令来检查

> -A : 对/etc/fstab 中所有列出来的 分区（partition）做检查

> -C : 显示完整的检查进度

> -d : 打印出 e2fsck 的 debug 结果

> -p : 同时有 -A 条件时，同时有多个 fsck 的检查一起执行

> -R : 同时有 -A 条件时，省略 / 不检查

> -V : 详细显示模式

> -a : 如果检查有错则自动修复

> -r : 如果检查有错则由使用者回答是否修复

> -y : 选项指定检测每个文件是自动输入yes，在不确定那些是不正常的时候，可以执行 # fsck -y 全部检查修复。

5、Linux 的磁盘挂载使用 mount 命令，卸载使用 umount 命令。

    mount [-t 文件系统] [-L Label名] [-o 额外选项] [-n]  装置文件名  挂载点

6、磁盘卸载命令 umount 语法

    umount [-fn] 装置文件名或挂载点

> 选项与参数：

> -f ：强制卸除！可用在类似网络文件系统 (NFS) 无法读取到的情况下；

> -n ：不升级 /etc/mtab 情况下卸除。


## linux vi/vim ##
### vim键盘图 ###
![](https://www.runoob.com/wp-content/uploads/2015/10/vi-vim-cheat-sheet-sch.gif)

## linux yum命令 ##
#### yum语法 ####
    yum [options] [command] [package ...]
> options：可选，选项包括-h（帮助），-y（当安装过程提示选择全部为 "yes"），-q（不显示安装的过程）等等。

> command：要进行的操作。

> package：安装的包名。

### yum常用命令 ###
> 1. 列出所有可更新的软件清单命令：yum check-update
> 
> 2. 更新所有软件命令：yum update

> 3. 仅安装指定的软件命令：yum install <package_name>
> 
> 4. 仅更新指定的软件命令：yum update <package_name>
> 
> 5. 列出所有可安裝的软件清单命令：yum list
> 
> 6. 删除软件包命令：yum remove <package_name>
> 
> 7. 查找软件包命令：yum search <keyword>
> 
> 8. 清除缓存命令:
> yum clean packages: 清除缓存目录下的软件包
> 
> yum clean headers: 清除缓存目录下的 headers
> 
> yum clean oldheaders: 清除缓存目录下旧的 headers
> 
> yum clean, yum clean all (= yum clean packages; yum clean oldheaders) :清除缓存目录下的软件包及旧的 headers

## linux apt命令 ##
### apt语法 ###
      apt [options] [command] [package ...]
> options：可选，选项包括 -h（帮助），-y（当安装过程提示选择全部为"yes"），-q（不显示安装的过程）等等。
> 
> command：要进行的操作。
> 
> package：安装的包名。

### apt常用命令 ###
> 列出所有可更新的软件清单命令：sudo apt update
> 
> 升级软件包：sudo apt upgrade
> 
> 列出可更新的软件包及版本信息：apt list --upgradeable
> 
> 升级软件包，升级前先删除需要更新软件包：sudo apt full-upgrade
> 
> 安装指定的软件命令：sudo apt install <package_name>
> 
> 安装多个软件包：sudo apt install <package_1<package_2<package_3>
> 
> 更新指定的软件命令：sudo apt update <package_name>
> 
> 显示软件包具体信息,例如：版本号，安装大小，依赖关系等等：sudo apt show <package_name>
> 
> 删除软件包命令：sudo apt remove <package_name>
> 
> 清理不再使用的依赖和库文件: sudo apt autoremove
> 
> 移除软件包及配置文件: sudo apt purge <package_name>
> 
> 查找软件包命令： sudo apt search <keyword>
> 
> 列出所有已安装的包：apt list --installed
> 
> 列出所有已安装的包的版本信息：apt list --all-versions

