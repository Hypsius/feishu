# python #
**1、python内置模块：sys，提供了与 Python 解释器及其环境交互的功能**

	sys.argv: 命令行参数的列表，包括脚本名称在内。
	sys.exit([arg]): 退出程序，可选地返回一个状态码。
	sys.path: 包含要在导入模块时搜索的目录名称的字符串列表。
	sys.modules: 一个字典，将模块名称映射到已加载的模块。
	sys.stdin, sys.stdout, sys.stderr: 分别用于标准输入、标准输出和标准错误的文件对象。

**2、python源文件的编码默认是UTF-8，标准库只用常规的ASCII字符作为变量名或函数名**
	
	# -*- coding: encoding -*-		#例如使用其他编码应注明

**3、配置环境后在终端键入python，可以打开python解释器运用简单的python命令，用作计算器等**
	
	>>>5 ** 2
	25

**4、字符串可以使用反斜杠 \ 用于转义，如果不希望前置\的字符转义成特殊字符，可以使用原始字符串，在引号前添加r即可**

	>>> print('C:\some\name')  # here \n means newline!
	C:\some
	ame
	>>> print(r'C:\some\name')  # note the r before the quote
	C:\some\name

**5、+-*%、字符串拼接、字符串切片、列表、元组、集合 、序列、字典**

**6、以脚本形式执行模块**

	if __name=="__main__":

**7、“已编译的”的python文件，为了快速加载模块，Python 把模块的编译版本缓存在 __pycache__ 目录中，文件名为 module.version.pyc，version 对编译文件格式进行编码，一般是 Python 的版本号。Python 在两种情况下不检查缓存。一，从命令行直接载入的模块，每次都会重新编译，且不储存编译结果；二，没有源模块，就不会检查缓存。为了让一个库能以隐藏源代码的形式分发（通过将所有源代码变为编译后的版本），编译后的模块必须放在源目录而非缓存目录中，并且源目录绝不能包含同名的未编译的源模块。**


**8、使用 from package import item 时，item 可以是包的子模块（或子包），也可以是包中定义的函数、类或变量等其他名称。import 语句首先测试包中是否定义了 item；如果未在包中定义，则假定 item 是模块，并尝试加载。如果找不到 item，则触发 ImportError 异常。**

	from pakeage import item	#item可以为包的子模块、包中定义的函数、类、变量名


**9、相反，使用 import item.subitem.subsubitem 句法时，除最后一项外，每个 item 都必须是包；最后一项可以是模块或包，但不能是上一项中定义的类、函数或变量。**

	import 包		#只能导入包或者模块

**10、% 运算符（求余符）也可用于字符串格式化。给定 'string' % values，则 string 中的 % 实例会以零个或多个 values 元素替换。此操作被称为字符串插值。**

	>>> import math
	>>> print('The value of pi is approximately %5.3f.' % math.pi)
	The value of pi is approximately 3.142.

**11、读写文件**
第一个实参是文件名字符串。第二个实参是包含描述文件使用方式字符的字符串。mode 的值包括 'r' ，表示文件只能读取；'w' 表示只能写入（现有同名文件会被覆盖）；'a' 表示打开文件并追加内容，任何写入的数据会自动添加到文件末尾。'r+' 表示打开文件进行读写。mode 实参是可选的，省略时的默认值为 'r'。

	>>> f = open('workfile', 'w', encoding="utf-8")
	调用 f.write() 时，未使用 with 关键字，或未调用 f.close()，即使程序正常退出，也**可能** 导致 f.write() 的参数没有完全写入磁盘。


**12、错误和异常**

	SyntaxError: invalid syntax		#译文：语法错误，无效的语法；一般常见于python语法写错了

	>>> 10 * (1/0)
	Traceback (most recent call last):
	  File "<stdin>", line 1, in <module>
	ZeroDivisionError: division by zero		#ZeroDivisionError 内置异常，不能被0除，使用方法错误
	>>> 4 + spam*3
	Traceback (most recent call last):
	  File "<stdin>", line 1, in <module>
	NameError: name 'spam' is not defined	#NameError 内置异常，名未被定义，如spam被赋值
	>>> '2' + 2
	Traceback (most recent call last):
	  File "<stdin>", line 1, in <module>
	TypeError: can only concatenate str (not "int") to str		#TypeError	内置异常，类型未被定义，如int、float、str


**13、try  except 语句的工作原理：首先，执行 try 子句 （try 和 except 关键字之间的（多行）语句）。
如果没有触发异常，则跳过 except 子句，try 语句执行完毕。**

如果在执行 try 子句时发生了异常，则跳过该子句中剩下的部分。 如果异常的类型与 except 关键字后指定的异常相匹配，则会执行 except 子句，然后跳到 try/except 代码块之后继续执行。

如果发生的异常与 except 子句 中指定的异常不匹配，则它会被传递到外部的 try 语句中；如果没有找到处理程序，则它是一个 未处理异常 且执行将终止并输出如上所示的消息。

	

**14、rase语句强制触发指定的异常**
	
	>>> raise NameError('HiThere')
	Traceback (most recent call last):
	  File "<stdin>", line 1, in <module>
	NameError: HiThere
	——————————————————————————————————————————
	>>> while True:
	...     try:
	...         x = int(input("Please enter a number: "))
	...         break
	...     except ValueError:
	...         print("Oops!  That was no valid number.  Try again...")

**15、with语句在执行完代码后，能及时、正确的清理方式使用文件对象**

	with open("myfile.txt") as f:
	    for line in f:
	        print(line, end="")

**16、类提供了把数据和功能绑定在一起的方法。创建新类时创建了新的对象 类型，从而能够创建该类型的新 实例。实例具有能维持自身状态的属性，还具有能修改自身状态的方法（由其所属的类来定义）。**
>对象之间相互独立，多个名称（甚至是多个作用域内的多个名称）可以绑定到同一对象。

**17、类定义语法：当进入类定义时，将创建一个新的命名空间，并将其用作局部作用域 。所有对局部变量的赋值都是在这个新命名空间之内。**

	class ClassName		#定义类：ClassName

**18、类对象支持两种操作：属性引用和实例化。（Class 对象）**
> 属性引用 使用 Python 中所有属性引用所使用的标准语法: obj.name。 有效的属性名称是类对象被创建时存在于类命名空间中的所有名称。 因此，如果类定义是这样的:

    class MyClass:
	    """A simple example class"""
	    i = 12345
	
	    def f(self):
	        return 'hello world'

> 那么 **MyClass.i** 和 **MyClass.f** 就是有效的**属性引用**，将分别返回一个整数和一个函数对象。 类属性也可以被赋值，因此可以通过赋值来更改 MyClass.i 的值。 __doc__ 也是一个有效的属性，将返回所属类的文档字符串: "A simple example class"。

> **类的实例化** 使用函数表示法：**x=MyClass（）**。 可以把类对象视为是返回该类的一个新实例的不带参数的函数。 举例来说（假设使用上述的类）:

	x = MyClass()

> 创建类的新 实例 并将此对象分配给局部变量 x。

> 实例化操作（“调用”类对象）会创建一个空对象。 许多类喜欢创建带有特定初始状态的自定义实例。 为此类定义可能包含一个名为 __init__() 的特殊方法，就像这样:

	def __init__(self):
 	    self.data = []

> 当一个类定义了 __init__() 方法时，类的实例化操作会自动为新创建的类实例发起调用 __init__()。 因此在这个例子中，可以通过以下语句获得一个新的已初始化实例:

	x = MyClass()

> 当然，__init__() 方法还可以有额外参数以实现更高灵活性。 在这种情况下，提供给类实例化运算符的参数将被传递给 __init__()。 

	>>> class Complex:
	...     def __init__(self, realpart, imagpart):
	...         self.r = realpart
	...         self.i = imagpart
	...
	>>> x = Complex(3.0, -4.5)
	>>> x.r, x.i
	(3.0, -4.5)


>  实例对象所能理解的唯一操作是属性引用。 有两种有效的属性名称：**数据属性**和**方法**。
>  
	![](https://github.com/Hypsius/MarkdownPad/blob/main/ClassName.png)


> **实例变量**用于**每个实例的唯一数据**，而**类变量**用于**类的所有实例共享的属性和方法**

	class Dog:

    kind = 'canine'         # class variable shared by all instances

    def __init__(self, name):
        self.name = name    # instance variable unique to each instance
	
	>>> d = Dog('Fido')
	>>> e = Dog('Buddy')
	>>> d.kind                  # shared by all dogs
	'canine'
	>>> e.kind                  # shared by all dogs
	'canine'
	>>> d.name                  # unique to d
	'Fido'
	>>> e.name                  # unique to e
	'Buddy'

> 共享数据可能在涉及 mutable 对象例如列表和字典的时候导致令人惊讶的结果。 例如以下代码中的 tricks 列表不应该被用作类变量，因为所有的 Dog 实例将只共享一个单独的列表

	class Dog:

    tricks = []             # mistaken use of a class variable

    def __init__(self, name):
        self.name = name

    def add_trick(self, trick):
        self.tricks.append(trick)

	>>> d = Dog('Fido')
	>>> e = Dog('Buddy')
	>>> d.add_trick('roll over')
	>>> e.add_trick('play dead')
	>>> d.tricks                # unexpectedly shared by all dogs
	['roll over', 'play dead']

> 正确的类设计应该使用实例变量

	class Dog:

    def __init__(self, name):
        self.name = name
        self.tricks = []    # creates a new empty list for each dog

    def add_trick(self, trick):
        self.tricks.append(trick)

	>>> d = Dog('Fido')
	>>> e = Dog('Buddy')
	>>> d.add_trick('roll over')
	>>> e.add_trick('play dead')
	>>> d.tricks
	['roll over']
	>>> e.tricks
	['play dead']

	[https://github.com/Hypsius/MarkdownPad/blob/main/instance%20variables.png](https://github.com/Hypsius/MarkdownPad/blob/main/instance%20variables.png)

**19、继承是面向对象编程中的一个重要概念，它允许一个类（称为子类或派生类）继承另一个类（称为父类或基类）的属性和方法。继承的关键思想是通过建立类之间的层次结构，使得子类可以共享父类的特性，同时可以在子类中添加新的特性或修改继承的特性。**

> 单一继承：假设我们有一个动物类 Animal，它有一些通用的属性和方法，比如 eat 和 sleep。现在我们想创建一个更具体的类 Dog，它是一种动物，并且具有一些独有的属性和方法，比如 bark。这时，我们可以使用继承：

	
	class Animal:
	    def eat(self):
	        print("Animal is eating")
	
	    def sleep(self):
	        print("Animal is sleeping")
	
	class Dog(Animal):
	    def bark(self):
	        print("Dog is barking")

> 在这个例子中，Dog 类继承了 Animal 类，因此可以使用 eat 和 sleep 方法，同时它还有自己独有的方法 bark。

> 多重继承：多重继承是指一个类可以同时继承自多个类。假设我们有一个 Bird 类，它有方法 fly。现在我们想创建一个类 Pegasus，它可以继承自 Horse 和 Bird，因为它具有马的特性和鸟的特性：

	class Horse:
	    def run(self):
	        print("Horse is running")
	
	class Bird:
	    def fly(self):
	        print("Bird is flying")
	
	class Pegasus(Horse, Bird):
	    pass

> 在这个例子中，Pegasus 类同时继承了 Horse 和 Bird 类，因此可以使用 run 和 fly 方法。

**20、私有变量**

	class MyClass:
    def __init__(self):
        self.public_variable = "I'm public!"
        self._protected_variable = "I'm protected!"
        self.__private_variable = "I'm private!"

    def get_private_variable(self):
        return self.__private_variable

	# 创建一个对象
	obj = MyClass()
	
	# 访问公共变量
	print(obj.public_variable)  # 输出: I'm public!
	
	# 访问受保护的变量
	print(obj._protected_variable)  # 输出: I'm protected!
	
	# 访问私有变量 - 会报错，因为它是私有的
	# print(obj.__private_variable)  # 这行代码将导致 AttributeError
	
	# 通过类提供的方法访问私有变量
	print(obj.get_private_variable())  # 输出: I'm private!

	在这个例子中，public_variable 是公共变量，可以直接访问。_protected_variable 是受保护的变量，
	它的命名约定表明应该被视为私有的，但实际上仍然可以被直接访问。
	__private_variable 是私有变量，无法直接从外部访问，但通过提供一个公共方法 get_private_variable，
	我们可以间接地访问私有变量。这种方式确保了私有变量的访问受到控制和限制。


**21、迭代器：迭代器（Iterator）就像是一个可以逐个访问元素的对象。让我们通过一个简单的 Python 代码示例来说明迭代器的概念：**

	class MyIterator:
		def __init__(self, data):
		    self.data = data
		    self.index = 0
	
		def __iter__(self):
		    return self
		
		def __next__(self):
		    if self.index < len(self.data):
		        result = self.data[self.index]
		        self.index += 1
		        return result
		    else:
		        raise StopIteration
		
	# 创建一个迭代器对象
	my_iterator = MyIterator([1, 2, 3, 4, 5])
	
	# 使用迭代器遍历元素
	for element in my_iterator:
	    print(element)

> 在这个例子中，MyIterator 类实现了 __iter__ 和 __next__ 方法。__iter__ 方法返回迭代器对象本身，而 __next__ 方法用于返回下一个元素。当没有元素可迭代时，__next__ 方法会引发 StopIteration 异常，表示迭代结束。

> 通过 for element in my_iterator 循环，我们可以依次遍历迭代器中的元素。这种迭代器的设计模式使得我们可以按需生成或处理元素，而不必一次性加载所有元素到内存中。这对于处理大型数据集或流式数据非常有用。

**22、生成器（Generator）是 Python 中用于生成一系列值的特殊类型。与迭代器类似，生成器也允许你逐个产生值，但是它的实现更为简洁。**

	def my_generator():
	    yield 1
	    yield 2
	    yield 3
	    yield 4
	    yield 5

	# 创建一个生成器对象
	gen = my_generator()
	
	# 使用生成器逐个获取值
	for value in gen:
	    print(value)


> 在这个例子中，my_generator 是一个生成器函数，其中使用 yield 语句逐个生成值。与普通函数不同，生成器函数在被调用时并不执行，而是返回一个生成器对象。每次调用生成器的 __next__ 方法时，函数会执行到 yield 处停止，返回当前值，等待下一次调用继续执行。

> 这种生成器的方式允许我们按需生成值，而不必一次性生成整个序列。这对于处理大量数据或需要逐步生成的情况非常有用。

**23、标准库简介**

a.操作系统接口

> os 模块提供了许多与操作系统交互的函数:

	>>> import os
	>>> os.getcwd()      # Return the current working directory
	'C:\\Python310'
	>>> os.chdir('/server/accesslogs')   # Change current working directory
	>>> os.system('mkdir today')   # Run the command mkdir in the system shell
	0

> 对于日常文件和目录管理任务， shutil 模块提供了更易于使用的更高级别的接口:

	>>> import shutil
	>>> shutil.copyfile('data.db', 'archive.db')
	'archive.db'
	>>> shutil.move('/build/executables', 'installdir')
	'installdir'

b.文件通配符

> glob 模块提供了一个在目录中使用通配符搜索创建文件列表的函数:

	>>> import glob
	>>> glob.glob('*.py')
	['primes.py', 'random.py', 'quote.py']

c.命令行参数

> 通用实用程序脚本通常需要处理命令行参数。这些参数作为列表存储在 sys 模块的 argv 属性中。例如，以下输出来自在命令行运行 python demo.py one two three

	>>> import sys
	>>> print(sys.argv)
	['demo.py', 'one', 'two', 'three']
	

> argparse 模块提供了一种更复杂的机制来处理命令行参数。 以下脚本可提取一个或多个文件名，并可选择要显示的行数:

> 当在通过 python top.py --lines=5 alpha.txt beta.txt 在命令行运行时，该脚本会将 args.lines 设为 5 并将 args.filenames 设为 ['alpha.txt', 'beta.txt']。

	import argparse

	parser = argparse.ArgumentParser(
	    prog='top',
	    description='Show top lines from each file')
	parser.add_argument('filenames', nargs='+')
	parser.add_argument('-l', '--lines', type=int, default=10)
	args = parser.parse_args()
	print(args)


d. 字符串模式匹配

> re 模块为高级字符串处理提供正则表达式工具。对于复杂的匹配和操作，正则表达式提供简洁，优化的解决方案:

	>>> import re
	>>> re.findall(r'\bf[a-z]*', 'which foot or hand fell fastest')
	['foot', 'fell', 'fastest']
	>>> re.sub(r'(\b[a-z]+) \1', r'\1', 'cat in the the hat')
	'cat in the hat'

> 当只需要简单的功能时，首选字符串方法因为它们更容易阅读和调试:

	>>> 'tea for too'.replace('too', 'two')
	'tea for two'

f.数学

> math 模块提供对浮点数学的底层C库函数的访问:

	>>> import math
	>>> math.cos(math.pi / 4)
	0.70710678118654757
	>>> math.log(1024, 2)
	10.0

> random 模块提供了进行随机选择的工具:

	>>> import random
	>>> random.choice(['apple', 'pear', 'banana'])
	'apple'
	>>> random.sample(range(100), 10)   # sampling without replacement
	[30, 83, 16, 4, 8, 81, 41, 50, 18, 33]
	>>> random.random()    # random float
	0.17970987693706186
	>>> random.randrange(6)    # random integer chosen from range(6)
	4


> statistics 模块计算数值数据的基本统计属性（均值，中位数，方差等）:

	>>> import statistics
	>>> data = [2.75, 1.75, 1.25, 0.25, 0.5, 1.25, 3.5]
	>>> statistics.mean(data)
	1.6071428571428572
	>>> statistics.median(data)
	1.25
	>>> statistics.variance(data)
	1.3720238095238095

g.互联网访问

> 有许多模块可用于访问互联网和处理互联网协议。其中两个最简单的 urllib.request 用于从URL检索数据，以及 smtplib 用于发送邮件:

	>>> from urllib.request import urlopen
	>>> with urlopen('http://worldtimeapi.org/api/timezone/etc/UTC.txt') as response:
	...     for line in response:
	...         line = line.decode()             # Convert bytes to a str
	...         if line.startswith('datetime'):
	...             print(line.rstrip())         # Remove trailing newline
	...
	datetime: 2022-01-01T01:36:47.689215+00:00
	
	>>> import smtplib
	>>> server = smtplib.SMTP('localhost')
	>>> server.sendmail('soothsayer@example.org', 'jcaesar@example.org',
	... """To: jcaesar@example.org
	... From: soothsayer@example.org
	...
	... Beware the Ides of March.
	... """)
	>>> server.quit()

h.日期和时间

> datetime 模块提供了以简单和复杂的方式操作日期和时间的类。虽然支持日期和时间算法，但实现的重点是有效的成员提取以进行输出格式化和操作。该模块还支持可感知时区的对象。

	>>> # dates are easily constructed and formatted
	>>> from datetime import date
	>>> now = date.today()
	>>> now
	datetime.date(2003, 12, 2)
	>>> now.strftime("%m-%d-%y. %d %b %Y is a %A on the %d day of %B.")
	'12-02-03. 02 Dec 2003 is a Tuesday on the 02 day of December.'
	
	>>> # dates support calendar arithmetic
	>>> birthday = date(1964, 7, 31)
	>>> age = now - birthday
	>>> age.days
	14368

i.数据压缩

> 常见的数据存档和压缩格式由模块直接支持，包括：zlib, gzip, bz2, lzma, zipfile 和 tarfile。:

	>>> import zlib
	>>> s = b'witch which has which witches wrist watch'
	>>> len(s)
	41
	>>> t = zlib.compress(s)
	>>> len(t)
	37
	>>> zlib.decompress(t)
	b'witch which has which witches wrist watch'
	>>> zlib.crc32(s)
	226805979

j.性能测量

> 一些Python用户对了解同一问题的不同方法的相对性能产生了浓厚的兴趣。 Python提供了一种可以立即回答这些问题的测量工具。例如，元组封包和拆包功能相比传统的交换参数可能更具吸引力。timeit 模块可以快速演示在运行效率方面一定的优势:

	>>> from timeit import Timer
	>>> Timer('t=a; a=b; b=t', 'a=1; b=2').timeit()
	0.57535828626024577
	>>> Timer('a,b = b,a', 'a=1; b=2').timeit()
	0.54962537085770791

> 与 timeit 的精细粒度级别相反， profile 和 pstats 模块提供了用于在较大的代码块中识别时间关键部分的工具。

k. 质量控制

> 开发高质量软件的一种方法是在开发过程中为每个函数编写测试，并在开发过程中经常运行这些测试。

> doctest 模块提供了一个工具，用于扫描模块并验证程序文档字符串中嵌入的测试。测试构造就像将典型调用及其结果剪切并粘贴到文档字符串一样简单。这通过向用户提供示例来改进文档，并且它允许doctest模块确保代码保持对文档的真实:

	def average(values):
    	"""Computes the arithmetic mean of a list of numbers.

	    >>> print(average([20, 30, 70]))
	    40.0
	    """
	    return sum(values) / len(values)
	
	import doctest
	doctest.testmod()   # automatically validate the embedded tests

> unittest 模块不像 doctest 模块那样易于使用，但它允许在一个单独的文件中维护更全面的测试集:

	import unittest
	
	class TestStatisticalFunctions(unittest.TestCase):
	
	    def test_average(self):
	        self.assertEqual(average([20, 30, 70]), 40.0)
	        self.assertEqual(round(average([1, 5, 7]), 1), 4.3)
	        with self.assertRaises(ZeroDivisionError):
	            average([])
	        with self.assertRaises(TypeError):
	            average(20, 30, 70)
	
	unittest.main()  # Calling from the command line invokes all tests

l.自带电池

> Python有“自带电池”的理念。通过其包的复杂和强大功能可以最好地看到这一点。例如:

> xmlrpc.client 和 xmlrpc.server 模块使得实现远程过程调用变成了小菜一碟。 尽管存在于模块名称中，但用户不需要直接了解或处理 XML。

> email 包是一个用于管理电子邮件的库，包括MIME和其他符合 RFC 2822 规范的邮件文档。与 smtplib 和 poplib 不同（它们实际上做的是发送和接收消息），电子邮件包提供完整的工具集，用于构建或解码复杂的消息结构（包括附件）以及实现互联网编码和标头协议。

>  json 包为解析这种流行的数据交换格式提供了强大的支持。 csv 模块支持以逗号分隔值格式直接读取和写入文件，这种格式通常为数据库和电子表格所支持。 XML 处理由 xml.etree.ElementTree ， xml.dom 和 xml.sax 包支持。这些模块和软件包共同大大简化了 Python 应用程序和其他工具之间的数据交换。

> sqlite3 模块是 SQLite 数据库库的包装器，提供了一个可以使用稍微非标准的 SQL 语法更新和访问的持久数据库。

> 国际化由许多模块支持，包括 gettext ， locale ，以及 codecs 包。


n.格式化输出

> reprlib 模块提供了一个定制化版本的 repr() 函数，用于缩略显示大型或深层嵌套的容器对象:

	>>> import reprlib
	>>> reprlib.repr(set('supercalifragilisticexpialidocious'))
	"{'a', 'c', 'd', 'e', 'f', 'g', ...}"

> pprint 模块提供了更加复杂的打印控制，其输出的内置对象和用户自定义对象能够被解释器直接读取。当输出结果过长而需要折行时，“美化输出机制”会添加换行符和缩进，以更清楚地展示数据结构:

	>>> import pprint
	>>> t = [[[['black', 'cyan'], 'white', ['green', 'red']], [['magenta',
	...     'yellow'], 'blue']]]
	...
	>>> pprint.pprint(t, width=30)
	[[[['black', 'cyan'],
	   'white',
	   ['green', 'red']],
	  [['magenta', 'yellow'],
	   'blue']]]

> textwrap 模块能够格式化文本段落，以适应给定的屏幕宽度:
	
	>>> import textwrap
	>>> doc = """The wrap() method is just like fill() except that it returns
	... a list of strings instead of one big string with newlines to separate
	... the wrapped lines."""
	...
	>>> print(textwrap.fill(doc, width=40))
	The wrap() method is just like fill()
	except that it returns a list of strings
	instead of one big string with newlines
	to separate the wrapped lines.

> locale 模块处理与特定地域文化相关的数据格式。locale 模块的 format 函数包含一个 grouping 属性，可直接将数字格式化为带有组分隔符的样式:

	>>> import locale
	>>> locale.setlocale(locale.LC_ALL, 'English_United States.1252')
	'English_United States.1252'
	>>> conv = locale.localeconv()          # get a mapping of conventions
	>>> x = 1234567.8
	>>> locale.format("%d", x, grouping=True)
	'1,234,567'
	>>> locale.format_string("%s%.*f", (conv['currency_symbol'],
	...                      conv['frac_digits'], x), grouping=True)
	'$1,234,567.80'

m.模板

> string 模块包含一个通用的 Template 类，具有适用于最终用户的简化语法。它允许用户在不更改应用逻辑的情况下定制自己的应用。

> 上述格式化操作是通过占位符实现的，占位符由 $ 加上合法的 Python 标识符（只能包含字母、数字和下划线）构成。一旦使用花括号将占位符括起来，就可以在后面直接跟上更多的字母和数字而无需空格分割。$$ 将被转义成单个字符 $:

	>>> from string import Template
	>>> t = Template('${village}folk send $$10 to $cause.')
	>>> t.substitute(village='Nottingham', cause='the ditch fund')
	'Nottinghamfolk send $10 to the ditch fund.'

> 如果在字典或关键字参数中未提供某个占位符的值，那么 substitute() 方法将抛出 KeyError。对于邮件合并类型的应用，用户提供的数据有可能是不完整的，此时使用 safe_substitute() 方法更加合适 —— 如果数据缺失，它会直接将占位符原样保留。

	>>> t = Template('Return the $item to $owner.')
	>>> d = dict(item='unladen swallow')
	>>> t.substitute(d)
	Traceback (most recent call last):
	  ...
	KeyError: 'owner'
	>>> t.safe_substitute(d)
	'Return the unladen swallow to $owner.'


> Template 的子类可以自定义分隔符。例如，以下是某个照片浏览器的批量重命名功能，采用了百分号作为日期、照片序号和照片格式的占位符:

	>>> import time, os.path
	>>> photofiles = ['img_1074.jpg', 'img_1076.jpg', 'img_1077.jpg']
	>>> class BatchRename(Template):
	...     delimiter = '%'
	...
	>>> fmt = input('Enter rename style (%d-date %n-seqnum %f-format):  ')
	Enter rename style (%d-date %n-seqnum %f-format):  Ashley_%n%f
	
	>>> t = BatchRename(fmt)
	>>> date = time.strftime('%d%b%y')
	>>> for i, filename in enumerate(photofiles):
	...     base, ext = os.path.splitext(filename)
	...     newname = t.substitute(d=date, n=i, f=ext)
	...     print('{0} --> {1}'.format(filename, newname))
	
	img_1074.jpg --> Ashley_0.jpg
	img_1076.jpg --> Ashley_1.jpg
	img_1077.jpg --> Ashley_2.jpg

> 模板的另一个应用是将程序逻辑与多样的格式化输出细节分离开来。这使得对 XML 文件、纯文本报表和 HTML 网络报表使用自定义模板成为可能。

o. 使用二进制数据记录格式

> struct 模块提供了 pack() 和 unpack() 函数，用于处理不定长度的二进制记录格式。下面的例子展示了在不使用 zipfile 模块的情况下，如何循环遍历一个 ZIP 文件的所有头信息。Pack 代码 "H" 和 "I" 分别代表两字节和四字节无符号整数。"<" 代表它们是标准尺寸的小端字节序:

	import struct
	
	with open('myfile.zip', 'rb') as f:
	    data = f.read()
	
	start = 0
	for i in range(3):                      # show the first 3 file headers
	    start += 14
	    fields = struct.unpack('<IIIHH', data[start:start+16])
	    crc32, comp_size, uncomp_size, filenamesize, extra_size = fields
	
	    start += 16
	    filename = data[start:start+filenamesize]
	    start += filenamesize
	    extra = data[start:start+extra_size]
	    print(filename, hex(crc32), comp_size, uncomp_size)
	
	    start += extra_size + comp_size     # skip to the next header

p.多线程

> 线程是一种对于非顺序依赖的多个任务进行解耦的技术。多线程可以提高应用的响应效率，当接收用户输入的同时，保持其他任务在后台运行。一个有关的应用场景是，将 I/O 和计算运行在两个并行的线程中。
> 
> 以下代码展示了高阶的 threading 模块如何在后台运行任务，且不影响主程序的继续运行:

	import threading, zipfile

	class AsyncZip(threading.Thread):
	    def __init__(self, infile, outfile):
	        threading.Thread.__init__(self)
	        self.infile = infile
	        self.outfile = outfile
	
	    def run(self):
	        f = zipfile.ZipFile(self.outfile, 'w', zipfile.ZIP_DEFLATED)
	        f.write(self.infile)
	        f.close()
	        print('Finished background zip of:', self.infile)
	
	background = AsyncZip('mydata.txt', 'myarchive.zip')
	background.start()
	print('The main program continues to run in foreground.')
	
	background.join()    # Wait for the background task to finish
	print('Main program waited until background was done.')

> 多线程应用面临的主要挑战是，相互协调的多个线程之间需要共享数据或其他资源。为此，threading 模块提供了多个同步操作原语，包括线程锁、事件、条件变量和信号量。

q.日志记录

> logging 模块提供功能齐全且灵活的日志记录系统。在最简单的情况下，日志消息被发送到文件或 sys.stderr

	import logging
	logging.debug('Debugging information')
	logging.info('Informational message')
	logging.warning('Warning:config file %s not found', 'server.conf')
	logging.error('Error occurred')
	logging.critical('Critical error -- shutting down')

	这会产生以下输出:
	WARNING:root:Warning:config file server.conf not found
	ERROR:root:Error occurred
	CRITICAL:root:Critical error -- shutting down

> 默认情况下，informational 和 debugging 消息被压制，输出会发送到标准错误流。其他输出选项包括将消息转发到电子邮件，数据报，套接字或 HTTP 服务器。新的过滤器可以根据消息优先级选择不同的路由方式：DEBUG，INFO，WARNING，ERROR，和 CRITICAL。

> 日志系统可以直接从 Python 配置，也可以从用户配置文件加载，以便自定义日志记录而无需更改应用程序。

r.弱引用

> Python 会自动进行内存管理（对大多数对象进行引用计数并使用 garbage collection 来清除循环引用）。 当某个对象的最后一个引用被移除后不久就会释放其所占用的内存。

> 此方式对大多数应用来说都适用，但偶尔也必须在对象持续被其他对象所使用时跟踪它们。 不幸的是，跟踪它们将创建一个会令其永久化的引用。 weakref 模块提供的工具可以不必创建引用就能跟踪对象。 当对象不再需要时，它将自动从一个弱引用表中被移除，并为弱引用对象触发一个回调。 典型应用包括对创建开销较大的对象进行缓存:

	>>> import weakref, gc
	>>> class A:
		    def __init__(self, value):
		        self.value = value
		    def __repr__(self):
		        return str(self.value)
	
	>>> a = A(10)                   # create a reference
	>>> d = weakref.WeakValueDictionary()
	>>> d['primary'] = a            # does not create a reference
	>>> d['primary']                # fetch the object if it is still alive
	10
	>>> del a                       # remove the one reference
	>>> gc.collect()                # run garbage collection right away
	0
	>>> d['primary']                # entry was automatically removed
	Traceback (most recent call last):
	  File "<stdin>", line 1, in <module>
	    d['primary']                # entry was automatically removed
	  File "C:/python312/lib/weakref.py", line 46, in __getitem__
	    o = self.data[key]()
	KeyError: 'primary'

s.用于操作列表的工具

> array 模块提供了一种 array() 对象，它类似于列表，但只能存储类型一致的数据且存储密度更高。下面演示了一个用双字节无符号整数数组来储存整数的例子（类型码为 "H"），而通常的用 Python 的 int 对象来储存整数的列表，每个表项通常要使用 16 个字节：

	>>> from array import array
	>>>	 a = array('H', [4000, 10, 700, 22222])
	>>>	 sum(a)
	26932
	>>> a[1:3]
	array('H', [10, 700])

> collections 模块提供了一种 deque() 对象，它类似于列表，但从左端添加和弹出的速度较快，而在中间查找的速度较慢。 此种对象适用于实现队列和广度优先树搜索

> 在替代的列表实现以外，标准库也提供了其他工具，例如 bisect 模块具有用于操作有序列表的函数

> heapq 模块提供了基于常规列表来实现堆的函数。 最小值的条目总是保持在位置零。 这对于需要重复访问最小元素而不希望运行完整列表排序的应用来说非常有用

t.十进制浮点运算
> decimal 模块提供了一种 Decimal 数据类型用于十进制浮点运算。 相比内置的 float 二进制浮点实现，该类特别适用于 
> 
> 财务应用和其他需要精确十进制表示的用途，控制精度，控制四舍五入以满足法律或监管要求，
> 
> 跟踪有效小数位，或用户期望结果与手工完成的计算相匹配的应用程序。


**24、虚拟环境和包**

a.创建虚拟环境
> 用于创建和管理虚拟环境的模块称为 venv。venv 通常会安装你可用的最新版本的 Python。如果您的系统上有多个版本的 Python，您可以通过运行 python3 或您想要的任何版本来选择特定的Python版本。



> 要创建虚拟环境，请确定要放置它的目录，并将 venv 模块作为脚本运行目录路径:

    python -m venv tutorial-env

> 虚拟环境的常用目录位置是 .venv。 这个名称通常会令该目录在你的终端中保持隐藏，从而避免需要对所在目录进行额外解释的一般名称。 它还能防止与某些工具所支持的 .env 环境变量定义文件发生冲突。

b.使用pip管理包

> 你可以使用一个名为 pip 的程序来安装、升级和移除软件包。 默认情况下 pip 将从 Python Package Index 安装软件包。 你可以在你的 web 浏览器中查看 Python Package Index。

> pip 有许多子命令: "install", "uninstall", "freeze" 等等。 （请在 安装 Python 模块 指南页查看完整的 pip 文档。）

> 您可以通过指定包的名称来安装最新版本的包：

	python -m pip install appium

> 您还可以通过提供包名称后跟 == 和版本号来安装特定版本的包：

	python -m pip install requests==2.6.0

> 你可以运行 python -m pip install --upgrade 以将软件包升级到最新版本：

	python -m pip install --upgrade requests

> 虚拟环境中删除一个或多个包所对应的名称：

	python -m pip uninstall requests

> 显示有关某个特定包的信息：

	python -m pip show requests

> 显示所有在虚拟环境中安装的包：

	python -m pip list

> python -m pip freeze 将产生一个类似的已安装包列表，但其输出会使用 python -m pip install 所期望的格式。 一个常见的约定是将此列表放在 requirements.txt 文件中：

	python -m pip freeze > requirements.txt

> 然后可以将 requirements.txt 提交给版本控制并作为应用程序的一部分提供。然后用户可以使用 install -r 安装所有必需的包：

	python -m pip install -r requirements.txt

**25、Python标准库**
> Python 标准库非常庞大，所提供的组件涉及范围十分广泛，正如以下内容目录所显示的。这个库包含了多个内置模块 (以 C 编写)，Python 程序员必须依靠它们来实现系统级功能，例如文件 I/O，此外还有大量以 Python 编写的模块，提供了日常编程中许多问题的标准解决方案。其中有些模块经过专门设计，通过将特定平台功能抽象化为平台中立的 API 来鼓励和加强 Python 程序的可移植性。

> 在标准库以外，还存在成千上万并且不断增加的其他组件集（从单独的程序和模块到软件包以及完整的应用程序开发框架），这些组件集可以从`Python 包索引 https://pypi.org 获取。

	https://docs.python.org/zh-cn/3.12/library/index.html#library-index		#内置库

	https://docs.python.org/zh-cn/3.12/library/index.html#library-index		#内置函数

	https://docs.python.org/zh-cn/3.12/library/constants.html		#内置常量

	https://docs.python.org/zh-cn/3.12/library/stdtypes.html		#内置类型

	https://docs.python.org/zh-cn/3.12/library/exceptions.html		#内置异常

	https://docs.python.org/zh-cn/3.12/library/text.html		#文本处理服务：string、re、difflib、textwrap、unicodedata、stringprep、readline

	https://pypi.org		#社区库

	https://docs.python.org	#快速访问Python的文档

	https://www.python.org		#Python 主网站。 它包含代码、文档和指向全网 Python 相关网页的链接

	https://code.activestate.com/recipes/langs/python/		#Python Cookbook是一个相当大的代码示例集，更多的模块和有用的脚本

	https://pyvideo.org		#收集了来自研讨会和用户组会议的 Python 相关视频的链接

	https://scipy.org		
	#Scientific Python 项目包含用于快速矩阵计算和操作的模块，.以及用于诸如线性代数，傅里叶变换，非线性求解器，随机数分布，统计分析等的一系列包

**26、命令行与环境**
> 最常见的用例是启动时执行脚本：

	python myscript.py

	-?
	-h
	--help
	打印所有命令行选项及对应环境变量的简短描述然后退出。
	
	--help-env
	打印 Python 专属环境变量的简短描述然后退出。
	
	3.11 新版功能.
	
	--help-xoptions
	打印实现专属 -X 选项的简短描述然后退出。
	
	3.11 新版功能.
	
	--help-all
	打印完整使用信息然后退出。
	
	3.11 新版功能.
	
	-V
	--version

**27、并发执行**

	https://docs.python.org/zh-cn/3.12/library/concurrency.html

**28、Tk图形用户界面（GUI）**

	https://docs.python.org/zh-cn/3.12/library/tk.html

**29、开发工具**

	https://docs.python.org/zh-cn/3.12/library/development.html

**30、调试和分析**

	https://docs.python.org/zh-cn/3.12/library/debug.html

**31、软件打包和分发**

	https://docs.python.org/zh-cn/3.12/library/distribution.html

**32、python使用总结**

a.使用	@classmethod	装饰器
> 使用 @classmethod 装饰器定义的方法是类方法。
> 
> 类方法通过 cls 参数访问类的属性和方法。
> 
> 类方法可以通过类本身调用，而不需要创建类的实例。

b.不使用	@classmethod	装饰器
> 在类中定义的普通方法是实例方法，带有 self 参数。
> 
> 实例方法需要通过创建类的实例来调用。
