
# 安装Docker #
	$ sudo apt-get remove docker docker-engine docker.io containerd runc	#卸载老的版本

	$ sudo apt-get update	#更新apt包索引

	$ sudo apt-get install \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg-agent \
    software-properties-common	安装必要工具包

	$ sudo apt-get install docker-ce docker-ce-cli containerd.io	# 安装docker

	sudo systemctl enable docker
	sudo systemctl start docker		#启动Docker

	docker run hello-world		#验证是否安装成功

# Docker常用的镜像管理命令 #
镜像仓库：hub.docker.com/

    docker pull {image_name}
	拉取镜像

	docker push {image_name}
	推送镜像

	docker images
	查看当前机器的所有镜像
	
	docker rmi {image_name}
	删除当前机器的一个镜像

	docker tag {source_images_name:tag your_image_name:tag}
	为一个镜像打tag

	docker save busybox > busybox.tar
	将镜像打包成tar包，可供无网络设备使用

	docker load < busybox.tar
	解压一个镜像tar包
	
# Docker常用的容器管理命令 #
    docker run -name={your_name} -d {image_name} 	
	运行容器 -d后台运行

	docker ps -s -a		
	查看当前所有容器

	docker stop {container_name} 	
	停止容器
	
	docker restart {container_name}
	启动容器

	docker kill {container_name} 	
	杀死容器
	
	docker rm -f {容器名称}		
	删除容器

	docker logs -f {容器名称}	
	查看容器日志

	docker inspect {容器名称}	
	查看容器的元数据

	docker exec -it {容器名称}
	bash进入容器，exec的意思是在容器中运行一个命令，如果是bash并且指定了-it就会打开容器的shell交互

	env
	查看环境变量

	docker cp {host_path} {container:name}:{container_path}
	把宿主机上的一个文件copy到容器中

# 安装jenkins #
	首选用ubuntu核心

    docker pull jenkins/jenkins:latest	#拉取hub.docker上的jenkins镜像

    docker run -d -p 10240:8080 -p 10241:50000 -v /var/myjenkins:/var/jenkins_home -v /etc/localtime:/etc/localtime --name myjenkins jenkins/jenkins
	-d 后台运行镜像
	-p 10240:8080 将镜像的8080端口映射到服务器的10240端口。
	-p 10241:50000 将镜像的50000端口映射到服务器的10241端口
	-v /var/myjenkins:/var/jenkins_home /var/jenkins_home目录为容器jenkins工作目录，我们将硬盘上的一个目录挂载到这个位置，方便后续更新镜像后继续使用原来的工作目录。这里我们设置的就是上面我们创建的 /var/jenkins_mount目录
	-v /etc/localtime:/etc/localtime让容器使用和服务器同样的时间设置。
	--name myjenkins 给容器起一个别名

	sudo chown -R 1000:1000 /var/myjenkins
	修改目录权限，因为当映射本地数据卷时，/var/myjenkins⽬录的拥有者为root用户，⽽容器中为jenkins ，要对其进行权限的修改，Jenkins的uid为1000

	docker logs -f myjenkins
	查看docker容器日志
	
	cd /var/myjenkins/
	vi  hudson.model.UpdateCenter.xml
	将 url 修改为 清华大学官方镜像：https://mirrors.tuna.tsinghua.edu.cn/jenkins/updates/update-center.json
	配置镜像加速
	
	访问jenkins页面：ip+端口，若无法访问（无法ping通）:
		1.华为云、腾讯云、阿里云的云服务器安全组协议要开放对应端口
		2.网络问题排错，使用ufw查看是否限制了网络
			2.1 sudo ufw status		#查看防火墙状态和端口开放
			2.2 sudo ufw enable		#打开防火墙
			2.3 sudo ufw allow 端口号	#打开防火墙端口
		3.检查宿主机的网络配置
			3.1 brctl show		#检查docker网桥，interfaces（虚拟网卡）有没有值
			3.2 systemctl  restart  docker		#重启docker，docker自动使用默认虚拟网卡
				3.2.1 systemctl stop docker.socket		#关闭docker守护进程（启动：start）
				3.3.2 systemctl stop docker.service		#关闭docker服务（启动：start）
		
	ps: 服务器内需要有程序使用并监听对应端口,才能ping通，仅仅开放端口也是无法ping通的



# 使用jenkins #
0、安装jdk1.8和maven

	1. sudo apt-get update		#更新软件包列表
	2. sudo apt-get install openjdk-8-jdk		#安装openjdk-8-jdk
	3. java --version		#查看java版本，看是否安装成功
	4. 在jenkins插件中安装Maven Integration		#安装maven

1、配置子节点，可以在其他服务器上控制运行任务
	
	一般可以配置自动的master服务器作为子节点
	1.宿主机通过SSH与子主机进行握手，生成私钥，文件路径：/root/.ssh
	2.jenkins新建配置子节点
		2.1 远程工作目录：一般为jenkins安装目录，如/var/myjenkins，对应权限要有读写执行权限，chmod 777 xxx
		2.2 启动方式：Launch agents via SSH 
		2.3	配置对应主机和凭证（SSH用户名和密码）
		2.4 主机密钥验证策略：Non verifying Verification Strategy
		2.5 端口：22
		2.6	Java路径：/usr/lib/jvm/java-19-openjdk-amd64/bin/java
		2.7	Remoting work directory：/var/myjenkins

2、配置Github

	可以通过任务拉取github代码
	1.在docker容器中生成公钥私钥
		1.1 docker exec -it 容器id或者容器名称 bash		#进入容器
		1.2 ssh-keygen -t rsa -C "youreamil@example.com"
	2.将生成的公钥id_rsa.pub配置到github的SSH keys上	文件路径：/root/.ssh
	3.容器中与github握手，在know_hosts自动生成密钥
		3.1 ssh git@github.com
	4.jenkins freestyle配置拉取git代码
		4.0	限制项目的运行节点-标签表达式：localhost_slave
		4.1 Repository URL: git@github.com:Hypsius/AutoApiVolunteer.git
		4.2 凭证类型：SSH Username with private key
		4.3 Enter directly：将生成的私钥id_rsa全部粘贴到此处
		4.4	指定分支：与github一致，*/main  */master
		4.5	Additional Behaviours 新增-检出到子目录：Volunteer
		4.6 Build Steps 新增-执行shell：build.sh	(命令集合脚本文件)
		4.7	全局安全配置-Host Key Verification Strategy：NO verification		#手动提供密钥无需验证

3、jenkins配置Email
	
	任务失败/构建不稳定/成功都可以发送邮件提醒
	1.安装插件：Email Extension，Email Extension Template
	2.系统配置-Jenkins Location
		2.1 Jenkins URL：http://60.204.174.201:10240/
		2.2 系统管理员邮件地址：caizhifeng@zdjx6.wecom.work		#腾讯企业微信邮箱的邮件地址
	3.系统配置-Extended E-mail Notification
		3.1	SMTP server：smtp.exmail.qq.com
		3.2 SMTP Port：465
		3.3 高级-添加凭证：Username with password
			3.3.1 用户名：caizhifeng@zdjx6.wecom.work
			3.3.2 密码：邮箱密码
			3.3.3 勾选Use SSL，Use TLS
		3.4 Default user e-mail suffix：@qq.com
		3.5 Default Content Type：HTML（test/html）
		3.6 Default Recipients：caizhifeng@zdjx6.wecom.work		#收件人邮箱
		3.7 Default Subject：Jenkins运行提示：$BUILD_STATUS | 脚本名称：$PROJECT_NAME | 运行编号：$BUILD_NUMBER		#标题模板
		3.8	Default Content：		#正文模板
				<hr/>（本邮件是程序自动下发，请勿回复！）<br/><hr/>
				项目名称：$PROJECT_NAME<br/><br/>

				项目描述：$JOB_DESCRIPTION<br/><br/>
				
				运行编号：$BUILD_NUMBER<br/><br/>
				
				运行结果：$BUILD_STATUS<br/><br/>
				
				触发原因：${CAUSE}<br/><br/>
				
				构建日志地址：<a href=“${BUILD_URL}console”>${BUILD_URL}console</a><br/><br/>
				
				构建地址：<a href=“$BUILD_URL”>$BUILD_URL</a><br/><br/>
				
				详情：${JELLY_SCRIPT,template="html"}<br/><hr/>
		3.9	Default Triggers：勾选Failure - 1st，Fixed
	4.可以使用Extended E-mail 测试邮件是否能发送
		4.1	Extended E-mail-SMTP服务器：smtp.exmail.qq.com
		4.2	Default user e-mail suffix：@qq.com
		4.3 勾选使用SMTP认证，输入用户名、密码
		4.4 勾选Use SSL，Use TLS
		4.5	SMTP端口：465
		4.6 Reply-To Address：caizhifeng@zdjx6.wecom.work
		4.7 字符集：UFT-8
		4.8 勾选 通过发送测试邮件测试配置 输入 Test e-mail recipient 发送测试
	5.若无法收到电子邮件，有如下原因
		5.1 云服务器安全规则是否打开		#上方安装docker有命令
		5.2 宿主机防火墙是否放开端口		#上方安装docker有命令
		5.3 端口在docker中是否映射宿主机
			5.3.1 docker ps -a		#查看容器信息
			5.3.2 docker port 容器ID/容器名称		#查看容器的端口映射情况，在容器外执行
			5.3.3 docker inspect b4c6 |grep Id		#查找要修改容器的容器Id
			5.3.4 进到/var/lib/docker/containers 目录下找到与 Id 相同的目录，修改 hostconfig.json 和 config.v2.json文件
			5.3.5 docker stop 容器ID		#停止容器
			5.3.6 systemctl stop docker		#停掉docker服务
			5.3.7 sudo systemctl stop docker.socket		#若无法停止docker服务，则先停止socket守护进程
			5.3.8 sudo systemctl stop docker.service	#停止docker服务
			5.3.9 修改hostconfig.json，添加端口绑定"465/tcp": [{"HostIp": "","HostPort": "465"}]，表示绑定端口465，保存
			5.3.10 修改config.v2.json，ExposedPorts中加上要暴露的端口465，"465/tcp":{}，保存
			5.3.11 sudo systemctl stop docker.service		#启动docker服务
			5.3.12 sudo systemctl start docker.socket		#启动docker守护进程
			5.3.13 docker ps -a		#查看容器信息，看端口是否已加上
	6.构建一个freestyle邮件项目
		6.1	构建后操作：Editable Email Notificaiton
			6.1.1 Project Recipient List：$DEFAULT_RECIPIENTS
			6.1.2 Project Reply-To List: $DEFAULT_REPLYTO
			6.1.3 Content Type:	Default Content Type
			6.1.4 Default Subject：$DEFAULT_SUBJECT
			6.1.5 Default Content：$DEFAULT_CONTENT


# Unbutu安装python3.10.0 #
	Linux非docker容器中安装python3.10.0，配合jenkins shell使用执行自动化测试
	1.安装依赖：sudo apt update
			   sudo apt install build-essential zlib1g-dev libncurses5-dev libgdbm-dev libnss3-dev libssl-dev libreadline-dev libffi-dev libsqlite3-dev wget libbz2-dev
	2.官网下载源文件：https://www.python.org/ftp/python/3.10.0/Python-3.10.0.tgz
	3.下载的源文件通过Finalshell上传至：/home/
	4.解压缩Python3.10.0：tar -zvxf Python-3.10.0.tgz
	5.开始安装：cd Python-3.10.0/
			   ./configure --enable-optimizations
	6.安装make：sudo make install
	7.编译make：make
	8.更新python默认指向为python3.10
		8.1 删除原有链接：rm /usr/bin/python
		8.2 找到python3的安装路径：which python3  #路径找到：/usr/local/bin/python3  
		8.3 建立软连接：ln -s /usr/local/bin/python3 /usr/bin/python
		8.4 验证是否建立软连接：python
							  exit()
		8.5 设置python的环境变量：vim  ~/.bashrc 
								在# some more ls aliases下插入保存下方命令
								alias python='usr/local/bin/python3'
		8.6 更新pip默认指向：which pip3	#路径找到：/usr/local/bin/pip3
						   ln -s /usr/local/bin/pip3 /usr/bin/pip
						   pip







jenkins 脚本控制台输入，让jenkins从格林威治时间修改为东八区上海时间
`System.setProperty('org.apache.commons.jelly.tags.fmt.timeZone','Asia/Shanghai') `


`shell 运行 exit 0 运行退出成功，输入非0皆失败`

