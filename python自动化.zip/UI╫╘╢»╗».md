# git bash #
	下载：https://blog.csdn.net/qq_36667170/article/details/79085301
	使用git bash，操作下方命令，目的：熟悉测开工具

# android自动化测试 #
## 使用真机或者模拟机测试 ##
	
	环境搭建：
	node：https://nodejs.org/en    #配置环境变量，一般安装时自动配置上了
	
	appium：npm install -g appium
			appium -v 	#查看安装后的版本，目的是否安装成功

	appium driver：appium driver install uiautomator2   #Appium扩展命令行模式，Android/mac平台，安装UIAutomator2/xcuitest驱动
				   appium driver list		#查看是否已经安装
				   appium		#启动appium server
	
	android studio:	https://developer.android.com/studio?hl=zh-cn	#安装后能下载依赖最好，下载不了只能手动下载对应依赖如下
					#配置系统变量，ANDROID_HOME用于运行时分析app的入口			
					D:\Program Files\Android\Android Studio
	
	android sdkmanager:https://developer.android.com/studio?hl=zh-cn
						#配置系统PATH路径
						%ANDROID_HOME%\cmdline-tools\bin

	android SDK Platform-Tools：https://developer.android.com/studio/releases/platform-tools?hl=zh-cn
							#配置系统PATH路径	
							%ANDROID_HOME%\Platform-Tools

	android SDK Builld-Tools:https://developer.android.com/tools?hl=zh-cn
							#配置系统PATH路径
							%ANDROID_HOME%\build-tools\34.0.0
								

	jdk：https://www.oracle.com/cn/java/technologies/downloads/
		 #配置环境变量 JAVA_HOME主要是为了调用java，所以java只要在path下，不设置也没关系
	
	appium-inspector：https://github.com/appium/appium-inspector/releases/tag/v2023.11.1
					pip install Appium-Python-Client	安装库

	scrcpy：https://github.com/Genymobile/scrcpy/releases/tag/v2.3.1		#配置环境变量

	adb connect 127.0.0.1:7555
	adb devices

	

## WIFI 调试 ADB ##
	使用：https://cloud.tencent.com/developer/article/1809910


## scrcpy键盘输入 ##
	https://cloud.tencent.com/developer/article/2286164

## appium settings ##
	使用appium中，自动手机安装：https://blog.csdn.net/ouyanggengcheng/article/details/85209296

## uiautomatorviewer定位元素 ##	
	不能与appium同时运行 

## 常见定位 ##
	-id	（resource-id）
	-accessibilityld 
	-xpath	全能支持	例如：AndroidClient.driver.find_element_by_xpath("//*[@test='自选']")

## 错误日志定位 ##
	运行错误可以在appium-server中查看日志进行定位

## 自定义控件识别 ##
	基本定位
	父控件定位+百分比定位
	图形识别
	ocr 图像文字识别

## appium-inspect使用 ##
	*platformName：指定测试的移动平台，可以是 "Android" 或 "iOS"。

	*deviceName：指定使用的设备名称，可以是设备的名称或设备的唯一标识符。

	*appPackage：指定要测试的应用的路径或包名，取决于你是使用本地应用还是已经安装的应用。

	*automationName:指定用于自动化测试的框架，可以是 "UiAutomator2"（Android）或 "XCUITest"（iOS）等。
	
	*appActivity：.view.WelcomeActivityAlias（程序入口文件）用于启动特定的应用组件

	*noReset:ture	# 指定在测试之间是否重置应用状态，这里是 true，表示不重置

	*platformVersion:指定设备的操作系统版本。
	
	udid：指定设备的唯一标识符。在多设备测试时，需要指定要使用的设备。

	autoGrantPermissions:true	#指定是否自动授予应用程序所需的权限

	chrmoderiverExecutableDir:/users/seveniruby/projects/chromedriver/2.20	# 指定 ChromeDriver 的可执行文件目录，用于支持 webview 相关的测试

	unicodeKeyboard:ture	#测试过程中控制是否使用 Unicode 键盘

	resetKeyboard:ture		#测试过程中控制是否重置键盘状态

	录制脚本 Recorder 开启后，进行页面操作，自动生成脚本，如python脚本、java脚本

	定位：resource-id、xpath（//*[@test='基金']）
	常用定位方法里xpath是一个不可缺失的重要手段，不建议使用绝对定位，使用相对定位是可以很好的维护测试用例的		

## adb 命令 ##
	adb shell pm list packages	获取所有已安装应用的包名
	adb shell dumpsys package <package_name> | grep -i MAIN	获取指定应用的启动 Activity

	生成appium日志： appium -g appium.log  -p 4723	
	查找apk有没有安装：adb shell pm list packages com.xueqiu.android
	查看分辨率大小：adb shell wm size
	查看运行进程：adb shell cat /proc/net/unix | findstr webview		#findstr/grep
	查看pid运行经常：adb shell ps 3795	#3795为pid

	清理apk数据：adb shell pm clear com.xueqiu.android
	如果设备断连，则重连后清理apk数据：adb kill-server
								   adb devices
								   adb shell pm clear com.xueqiu.android

## appium日志 ##
	adb devices 判断待测系统
	安装settings apk unclock
	推送uiautomator到手机并启动
	启动app
	http请求 element elements click value
	
## uiautomatorviewer ##	
	查找路径：which uiautomatorviewer
	找到路径后去对应文件夹打开uiautomatorviewer
	
## webview测试 ##
### 模拟器上的测试 ###
	网易mumu 模拟器
	webview控件会被映射为原生控件，类型为view，其中的文本内容会变成content-desc或者test
	安卓6.0会把webview中的控件变成一个带有content-desc属性的view控件
	安卓9.0会把webview中的控件变成一个带有text属性的view控件	

### 真机 ###
	如果app未开启webview的调试属性，是无法分析内部的控件的
	个别手机可能会默认打开此属性，所以默认也能访问到h5内部的控件
	如果还是访问不到，检查webview的调试属性是否开启，此时需要让研发配合打开webview的调试属性
 

### webview技术原理 ###
	将进程映射到对应7777端口，就可以浏览器访问该webview
	localhost:~ seveniruby$ adb shell cat /proc/net/unix | grep webview
		0000000000000000:00000002 00000000 00010000 0001 01 2545836 @webview devtoois remote_32073
		0000000000000000:00000002 00000000 00010000 0001 01 9455057 @webview-devtoois remote_25324

	adb -s VED7N18403003958 forward tcp:7777 localabstract:webview_devtools_remote_32073
	adb forward --list
	curl http://127.0.0.1:7777/json/version

### 包 ###
	不需要css定位：直接使用accessibility-id或者xpath定位就可以直接定位到
	需要css定位以及其他js执行功能：contests api + selenium css定位

	from appium.webdriver import webdriver
	from appium.webdriver.webdriver import WebDriver
	import pytest

## page object模式 ##
	https://cloud.tencent.com/developer/article/1865580
	书籍：《head first 设计模型》、《重构 改善既有代码的设计》  作者：MartinFowler

## PO的原则 ##
	单一责任原则（Single Responsibility Principle）：
	每个 Page Object 应该专注于一个特定的页面或者功能，并提供与该页面或功能相关的方法。这有助于维持代码的清晰度和可维护性。

	封装性（Encapsulation）：
	Page Object 应该封装与页面交互的细节，隐藏实现的具体细节。测试用例应该通过 Page Object 的公共接口与页面进行交互，而不是直接访问页面元素或操作。

	可重用性（Reusability）：
	设计 Page Object 时应考虑到它的可重用性。如果同一页面在多个测试用例中使用，可以重复使用相同的 Page Object，从而减少代码重复。

	独立性（Independence）：
	每个 Page Object 应该是相互独立的，不应该依赖于其他 Page Object 的内部实现。这样做有助于确保对一个页面的修改不会影响到其他页面的测试。

	命名一致性（Naming Consistency）：
	为 Page Object 的方法和属性选择清晰而一致的命名。这有助于测试人员更容易理解和使用 Page Object。

	维护性（Maintainability）：
	Page Object 应该是易于维护的。当应用程序的页面发生变化时，只需更新相关的 Page Object，而不需要修改测试用例。

	抽象层次（Abstraction）：
	Page Object 应该提供足够的抽象，使测试人员不需要了解页面的具体实现细节，只需关心与测试相关的行为。

	与测试框架无关性（Framework Independence）：
	尽量使 Page Object 与具体的测试框架无关，以便在需要更改测试框架时，不必修改所有的 Page Objects。

	这些原则有助于确保 Page Object 模式在测试自动化中的有效实施，提高测试代码的可读性、可维护性和稳定性。

## PO方法的意义 ##
	用公共方法代表UI所提供的功能
	方法应该返回其他的page object或者返回用于断言
	同样的行为不同的结果可以建模为不同的方法
	不要再方法内加断言
	
## PO字段意义 ##
	不要暴露页面内部的元素给外部
	不需要建模UI内的所有元素

## pycharm ##
	自己写用例或者使用录制脚本，进行运行，查看是否能成功运行
	appium capabilities：https://appium.io/docs/en/2.1/guides/caps/
	
	设置-工具-python集成工具-默认测试运行程序：pytest

## PO的主要组成元素 ##
	Page对象：完成对页面的封装				#创建 page python包
	Driver对象：完成对web、android、ios、接口的驱动		#创建 driver python包
	测试用例：调用Page对象实现业务并断言		#创建 testcase python包
	数据封装：配置文件和数据驱动
	Utils：其他功能封装，改进原生框架的不足
	 
## todo用法 ##
	在 PyCharm 和许多其他集成开发环境（IDE）中，使用 # TODO 注释是一种标记代码中需要后续处理的部分的常见方式。这种注释的目的是在代码中标记一些待办事项，以便开发人员在稍后的时间可以轻松找到并处理这些事项。
	# TODO 注释通常包含在代码中，后面跟随着一些描述性的文字，用于说明待办事项的具体内容或需要采取的行动。例如：
			# TODO: 添加错误处理代码
			def my_function():
			    # 一些代码
			    pass
## 链式调用 ##
	链式调用常见于构建器模式、流式接口等场景，其中每个方法都会对对象进行一些修改，并返回对象本身以支持后续的调用。这种风格的代码在某些情况下可以提高代码的可读性和可维护性。
	class Calculator:
    def __init__(self, value=0):
        self.value = value

    def add(self, x):
        self.value += x
        return self

    def subtract(self, x):
        self.value -= x
        return self

    def multiply(self, x):
        self.value *= x
        return self

    def divide(self, x):
        self.value /= x
        return self
	
	# 使用链式调用
	result = Calculator(5).add(3).multiply(2).divide(4).subtract(1).value
	print(result)  # 输出 (5 + 3) * 2 / 4 - 1 = 3.0


## python命名规则 ##
	在 Python 中，良好的命名习惯对于代码的可读性和维护性至关重要。Python 社区通常遵循一些命名约定，这有助于编写一致和易于理解的代码。以下是一些常见的 Python 命名约定：
	
	变量名： 使用小写字母，用下划线分隔单词，例如 my_variable。
	
	常量： 使用大写字母，用下划线分隔单词，例如 MY_CONSTANT。
	
	函数和方法名： 使用小写字母，用下划线分隔单词，例如 my_function。
	
	类名： 使用驼峰式命名，即首字母大写，单词之间无下划线，例如 MyClass。
	
	模块名： 使用短小的小写字母，可以使用下划线分隔，例如 my_module。
	
	包名： 使用简短、小写的名字，避免使用下划线，例如 mypackage。
	
	方法名： 类的方法使用与函数相同的命名规则。
	
	私有变量和方法： 在变量名或方法名前加上一个下划线，表示这是一个私有的成员，例如 _my_private_variable。
	
	受保护的成员： 在变量名或方法名前加上两个下划线，例如 __my_protected_variable。这个命名约定触发了名称改写（name mangling），使得该成员在类外部更难直接访问。
	
	特殊变量和方法： 有些特殊用途的变量和方法，如 __init__、__str__ 等，有一些特殊的命名规则，通常以双下划线开头和结尾。



# iOS自动化测试 #
	https://developer.apple.com/xcode
	https://github.com/appium/ios-uicatalog
	 
	

## Mac系统才能自动化ios ##
	使用Xcode模拟器软件，进行模拟iPhone
		1.git clon 软件实例，例如：https://github.com/appium/ios-uicatalog
		2.在mac文件中 use Xcode to open
		3.打开后在xcode中进行构建、运行

## 模拟器和真机两者的重要区别点 ##
	1.签名与privisioning  profile文件
	2.debug-iPhoneos/uicatalog.app、debug-iPhonesimlator/uicatalog.ap
		模拟器和真机路径不一致，如果用错了路径会导致测试失败

## 开发者工具 ##
	https://developer.apple.com/download/more/?=for%20xcode

## 开发者中心 
	https://developer.apple.com/account
	Team ID:xxxxxxx

## 测试框架 ##
	XCUITest 要求使用swift oc，只有开发工程师才适合使用
	Facebook开源的WDA
	Appium基于WDA做了一次兼容封装

## 模拟器自动化app ##
	platformName:ios
	platformVerson:12.1
	deviceName:iPhone X
	app:/users/..../uicatalog.app
	注意app是面向模拟器构建的，还是面向真机构建的

## 真机自动化app ##
	platformName:ios
	platformVerson:12.1
	deviceName:iPhone X
	app:/users/..../uicatalog.app
	xcodeOrgId：Team ID
	xcodeSigningId：iPhone developer

## 真机webview自动化=小程序 ##
	brew install--HEAD lbimobiledevice
	brew install ios-webkit-debug-proxy
	settings > safari > advanced > web inspector -> on

## 真机浏览器测试 ##
	platformName:ios
	platformVerson:12.1
	deviceName:iPhone X
	app:/users/..../uicatalog.app
	xcodeOrgId：Team ID
	xcodeSigningId：iPhone developer
	browserName：Safari

### 查看运行中的日志 ###
	less appium.log

## iOS设备命令行工具 ##
libimobiledevice 是一个开源的软件库，用于与 iOS 设备通信。它提供了一组工具和库，使开发人员能够通过命令行或其他程序与连接的 iOS 设备进行交互。以下是关于 libimobiledevice 的一些基本信息
	
	其中一些命令：
	ideviceinfo：获取设备信息。
	idevicescreenshot：获取设备屏幕截图。
	ideviceinstaller：用于安装和卸载应用程序。
	idevicedebug：调试代理工具。

## 依赖
	ios-deploy
	https://github.com/google/ios-webkit-debug-proxy
	http://appium.io/docs/en/drivers/ios-xcuitest-real-devices/
	idevicescreenshot

## WebDriverAgent安装与启动 ##
	git clone https://github.com/facebook/WebDriverAgent.git
	cd WebDriverAgent/
	#启动模拟器的应用
	xcodebuild -project WebDriverAgent xcadeproj \
		-scheme WebDriverAgentRunner\
		destination platform=iOS Simulator name=iPhone 6' \
		test

	#启动真机
	xcodebuild -project WebDriverAaent xcodeproj \
		-schemne WebDriverAgentRunner\
		-destination 'platform=iOS name='iphone X \
		test

## 设置苹果开发者账号 ##


## 架构 ##
	page_object	
		data	yaml文件
		driver	安卓驱动文件
		page	应用页面文件包括：basepage、mainpage、loginpage
		testcase：测试用例

## 显示等待 ##


## 弹窗拦截 ##

## yaml数据驱动 ##
	https://pyyaml.org/
	https://www.ruanyifeng.com/blog/2016/07/yaml.html

	可以使用yaml里面的锚点 defaults 来引用锚点，做到解决代码元素复用的情况

## 变化内容 ##
	定位符发生变化，需要支持多平台
	操作流程可能会发生
	多平台
	变量化
	
## 抽象原则 ##
	抽离变化部分，android与ios，页面一致，使用同一个数据文件维护。小程序、H5、web差别很大，独立封装为不同的数据文件。
	封装层次不要太深，逻辑太深维护不合理




##  编写代码 ## 
	安装 Appium-Python-Client
	pip install Appium-Python-Client


----------------------------------------------------
----------------------------------------------------
----------------------------------------------------

# Web自动化测试 #
## 安装selenium、chrome、chromedriver ##
> 最新版本的chrome和chromedriver可以到goole中安装

	https://googlechromelabs.github.io/chrome-for-testing/

> 执行完实例后会自动关闭浏览器，需要进行对应配置参数

	https://www.selenium.dev/documentation/webdriver/browsers/chrome/
	options = webdriver.ChromeOptions()
	options.add_experimental_option("detach", True)
	driver = webdriver.Chrome(options=options)
	driver.get("https://baidu.com")

## XPATH使用 ##
> xpath基础

	https://www.cnblogs.com/hanmk/p/8997786.html

常用xpath定位
		
>属性值定位： xpath = "//标签名[@属性='属性值']"

	<span class="universe-icon switch-icon" style="font-size: 38px;">上一步</span>
	xpath = "//span[@class='universe-icon switch-icon']"


> text()方法定位：xpath = "//标签名[text()='text']"

	<span class="universe-icon switch-icon" style="font-size: 38px;">上一步</span>
	xpath = "//span[text()='上一步']"


> contains()方法定位，也叫模糊定位：xpath = "//标签名[contains(@属性, '属性值')]"

	<span class="universe-icon switch-icon" style="font-size: 38px;">上一步</span>
	xpath = "//a[contains(@class, 'universe')]" 

	
> 如果一个元素无法通过自身属性直接定位到，就一级级从父到子定位

	百度输入框定位
	xpath = "//form[@id='form']/span[contains(@class,'s_ipt_wr')]/input"
	
